﻿ANSI/NIST-ITL 1-2000 Type-8 signature image files do not contain width and height information inside the file, however without knowing width and height, the image cannot be neither decoded nor encoded.
Please enter manually width and height of the image.
ANSI/NIST-ITL 1-2000 Type-8 signature image can be stored can be in two formats:
1) Uncompressed scanned binary image data;
2) ANSI/EIA-538-1988 facsimile compression.


In this sample collection signature image files have extension *.bin.
Additionally we provide *.txt files which contain information about image compression and width and height.
*.txt files have the same name as *.bin files and help to load signature images into “WSQ viewer”.
Please note that these *.txt files are not defined in ANSI/NIST-ITL 1-2000 Type-8 signature image standard and usually before loading image you need manually provide information about image compression and width and height.

